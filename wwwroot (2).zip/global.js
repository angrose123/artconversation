//global variables
// 1: create nPoints and set to 0
var nPoints = 0;
// 2: create txtStats and set to ""
var txtStats = "";
// 3: create arrStats as a new array
var arrStats = [];
// 4: create textStats as a new array
var textStats = [];
// 5: create nAlgo and set to 0
var nAlgo = 0;
// 6: create minR and set to 0
var minR = 0;
// 7: create maxR and set to 0
var maxR = 0;
var numItems = 0;
var pathSegments = 200;
var textMetrics = new Array;
var dotInterval;
var minR = 5;
var maxR = 100;