//runs the performance-tests in sequence (takes a few minutes)
require('./adverb-adj');
require('./infinitive-participle');
require('./named-entities');
// require('./question-forms');
// require('./uk-us_localization');
require('./verb-conjugation');
