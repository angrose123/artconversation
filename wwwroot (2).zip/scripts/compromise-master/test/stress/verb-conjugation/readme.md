list of verb conjugations taken from silentrob/tense.
https://github.com/silentrob/tense