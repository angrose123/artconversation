module.exports = {
  data: require('../data'),
  lexicon: require('../data'),
  fns: require('../fns'),
  Term: require('../term')
};
