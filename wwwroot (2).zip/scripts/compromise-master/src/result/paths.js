module.exports = {
  fns: require('../fns'),
  data: require('../data'),
  Terms: require('../terms'),
  tags: require('../tagset'),
};
