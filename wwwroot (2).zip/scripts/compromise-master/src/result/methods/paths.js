module.exports = require('../paths');
