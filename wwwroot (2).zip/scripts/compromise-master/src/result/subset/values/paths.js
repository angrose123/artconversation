module.exports = require('../../paths');
