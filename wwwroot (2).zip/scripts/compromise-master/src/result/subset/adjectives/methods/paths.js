module.exports = require('../../../paths');
