'use strict';
module.exports = {
  toNoun: require('./toNoun'),
  toSuperlative: require('./toSuperlative'),
  toComparative: require('./toComparative'),
  toAdverb: require('./toAdverb'),
  toVerb: require('./toVerb')
};
