module.exports = {
  Date: {}, //not a noun, but usually is
  Month: {
    is: 'Date',
    also: 'Singular'
  },
  WeekDay: {
    is: 'Date',
    also: 'Noun'
  },
  RelativeDay: {
    is: 'Date'
  },
  Year: {
    is: 'Date'
  },
  Duration: {
    is: 'Date',
    also: 'Noun'
  },
  Time: {
    is: 'Date',
    also: 'Noun'
  },
  Holiday: {
    is: 'Date',
    also: 'Noun'
  },
};
