module.exports = {
  fns: require('../fns'),
  log: require('../log'),
  tags: require('../tagset')
};
