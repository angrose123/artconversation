module.exports = {
  fns: require('../fns'),
  lexicon: require('../data/lexicon'),
  tries: require('../tries'),
  data: require('../data'),
  Terms: require('../terms'),
};
