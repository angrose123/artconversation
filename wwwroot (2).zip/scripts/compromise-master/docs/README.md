for the pretty version, see [compromise.cool/docs](http://compromise.cool/docs)

this is the json version of the docs, which are run [as part of the unit tests](../tests/unit/docs/docs.test.js)
this ensures that the docs stay somewhat up-to-date
