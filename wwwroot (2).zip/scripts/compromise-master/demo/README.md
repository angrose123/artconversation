
check out the interesting demos at [http://compromise.cool/demos](compromise.cool/demos).

these are a some simple static examples to help get things going.

you can view them running at:
 * [https://rawgit.com/nlp-compromise/compromise/master/demo/keypress/index.html](keyPress demo)
 * [https://rawgit.com/nlp-compromise/compromise/master/demo/webworker/index.html](webWorker demo)


or to run them locally,
```bash
git clone https://github.com/nlp-compromise/compromise.git
npm install
npm run demo
```
